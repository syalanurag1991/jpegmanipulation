#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <math.h>
#include <jerror.h>
#include <jpeglib.h>
#include <setjmp.h>
#include <string.h>

	
	/*The standard inout to the read function is a JPEG image.
 	* The function read_jpeg_file Reads from a JPEG file on disk
 	* specified by filename and saves into the raw_image buffer
 	* in an uncompressed format. It returns positive integer if 
 	* successful, -1 otherwise. Parameter "char *nameOfJPEGfile" 
 	* specifies the JPEG file to read from.
 	*/
int read_JPEG_file(char *nameOfJPEGfile, bool writeRAWfile, char *nameOfOutputRAWfile)
{
	//Defining the data structure for storing the raw image
	unsigned char *raw_image = NULL;
	unsigned int size;

	//printf("\n%s\n", nameOfJPEGfile);
    /* these are standard libjpeg structures for reading(decompression) */
    struct jpeg_decompress_struct cinfo;
    struct jpeg_error_mgr jerr;
    
	/* libjpeg data structure for storing one row, that is, scanline of an image */
	/* Output row buffer */
    JSAMPROW row_pointer[1];
    /* Physical row width in output buffer */
	int row_stride;
    
	FILE *infile = fopen(nameOfJPEGfile, "rb");
	//printf("%ld", infile);
    
    int i = 0;
    if (!infile)
	{
        printf("\nError opening JPEG file %s!\n", infile);
        return 0;
    }

	void print_jpeg_info(struct jpeg_decompress_struct cinfo)
	{
    	printf("\nJPEG File info: ");
    	printf("\n	Image width and height: %d x %d", cinfo.image_width, cinfo.image_height);
    	printf("\n	Color components per pixel: %d", cinfo.num_components);
    	printf("\n	Color space: %d", cinfo.jpeg_color_space);
    	//printf("\n	Raw flag is: %d", cinfo.raw_data_out);
	}

   
    /*STEP 1: Here we set up the standard libjpeg error handler 
	the "err" seems to be an attribute of the object created of class cinfo
	It's nothing but a pointer "jerr", where "jerr" is the location to be pointed to in case of an error*/
    cinfo.err = jpeg_std_error(&jerr);
    
	/* setup decompression process and source, then read JPEG header
	cinfo is pointer to the location where the file is stored temporarily*/
    jpeg_create_decompress(&cinfo);
    
	/*STEP 2: This assignes a source to the address "cinfo",
	basically makes the library read from infile and store it at "cinfo" \*/
    jpeg_stdio_src(&cinfo, infile);
    
	/*STEP 3: Reading the image header which contains image information
	TRUE ensures that we will write a complete interchange-JPEG file.
    Pass TRUE unless you are very sure of what you're doing.*/
    jpeg_read_header(&cinfo, TRUE);
    print_jpeg_info(cinfo);
    
	/*STEP 4: Start Decompression.
	NOTE: In this example, we don't need to change any of the defaults set by
    jpeg_read_header(), so we do nothing here.*/
	jpeg_start_decompress(&cinfo);

    /* allocate memory to hold the uncompressed image 
	Example, a color image of size 600px by 400px will have num_components = 3*/
	size = cinfo.output_width*cinfo.output_height*cinfo.num_components;
	raw_image = (unsigned char*)malloc(size);
	/* We may need to do some setup of our own at this point before reading
    the data.  After jpeg_start_decompress() we have the correct scaled
    output image dimensions available, as well as the output colormap
    if we asked for color quantization.
    
	In this example, we need to make an output work buffer of the right size.*/ 
    /* JSAMPLEs per row in output buffer.
	So a 600px long row of a color image will have a size of 1800*/
	row_stride = cinfo.output_width * cinfo.output_components;
    
	/* now actually read the jpeg into the raw buffer */
    row_pointer[0] = (unsigned char *)malloc(row_stride);
    
    
    /*STEP 5: Here we use the library's state variable cinfo.output_scanline as the
    loop counter, so that we don't have to keep track ourselves.
    Read one scan line at a time */
    unsigned long location = 0;
    while (cinfo.output_scanline < cinfo.image_height)
    {
    	/* Here, "jpeg_read_scanlines" expects an array of pointers to scanlines.
     	Since the "row_pointer" array is only "1" element long, we pass it the address of the 1st pointer, i.e. cinfo*/
        jpeg_read_scanlines(&cinfo, row_pointer, 1 );
        
        for (i=0; i<cinfo.image_width*cinfo.num_components;i++)
        {
            raw_image[location++] = row_pointer[0][i];
        }
    }

     /*STEP 6: Wrap up decompression, destroy objects, free pointers and close open files */
    jpeg_finish_decompress(&cinfo);
    jpeg_destroy_decompress(&cinfo);
    free(row_pointer[0]);
    fclose(infile);
    /* yup, we succeeded! */


    //STEP 7(OPTIONAL): Output the rawfile if needed
    //RAW File writing block

    if(writeRAWfile)
    {
    	FILE *outputRAWfile;
    	outputRAWfile = fopen(nameOfOutputRAWfile, "w");
    	fwrite(raw_image, sizeof(char), size, outputRAWfile);
    	fclose(outputRAWfile);	
    }
    
    return 3;
}



	/*The standard input image format is a rectangular array of pixels, with
 	* each pixel having the same number of "component" values (color channels).
 	* Each pixel row is an array of JSAMPLEs (which typically are unsigned chars).
 	* If you are working with color data, then the color values for each pixel
 	* must be adjacent in the row; for example, R,G,B,R,G,B,R,G,B,... for 24-bit
 	* RGB color.
 	*/

int write_JPEG_file (char *filename, int quality, int image_height, int image_width, int numberOfComponents, J_COLOR_SPACE colorSpace, char *rawFileName)
{

	FILE *rawfile = fopen(rawFileName, "rb");
	//printf("\nReading RAW file: %s\n", rawFileName);	
    if (!rawfile)
	{
        printf("\n\nError opening RAW file %s!\n", rawfile);
        return 0;
    }


	JSAMPLE *image_buffer; /* Points to large array of R,G,B-order data */
	long image_size = image_height*image_width*numberOfComponents; /* Number of rows in image*Number of columns in image */
	image_buffer = (JSAMPLE*) malloc(image_size);
	fread(image_buffer, sizeof(char), image_size, rawfile);
	
	/* This struct contains the JPEG compression parameters and pointers to
	* working space (which is allocated as needed by the JPEG library).
	* It is possible to have several such structures, representing multiple
	* compression/decompression processes, in existence at once.  We refer
	* to any one struct (and its associated working data) as a "JPEG object".
	*/
	struct jpeg_compress_struct cinfo;
	/* This struct represents a JPEG error handler.  It is declared separately
	* because applications often want to supply a specialized error handler
	* (see the second half of this file for an example).  But here we just
	* take the easy way out and use the standard error handler, which will
	* print a message on stderr and call exit() if compression fails.
	* Note that this struct must live as long as the main JPEG parameter
	* struct, to avoid dangling-pointer problems.
	*/
	struct jpeg_error_mgr jerr;
	/* More stuff */
	FILE * outfile;		/* target file */
	JSAMPROW row_pointer[1];	/* pointer to JSAMPLE row[s] */
	int row_stride;		/* physical row width in image buffer */

	/* Step 1: allocate and initialize JPEG compression object */

	/* We have to set up the error handler first, in case the initialization
	* step fails.  (Unlikely, but it could happen if you are out of memory.)
	* This routine fills in the contents of struct jerr, and returns jerr's
	* address which we place into the link field in cinfo.
	*/
	cinfo.err = jpeg_std_error(&jerr);
	/* Now we can initialize the JPEG compression object. */
	jpeg_create_compress(&cinfo);

	/* Step 2: specify data destination (eg, a file) */
	/* Note: steps 2 and 3 can be done in either order. */

	/* Here we use the library-supplied code to send compressed data to a
	* stdio stream.  You can also write your own code to do something else.
	* VERY IMPORTANT: use "b" option to fopen() if you are on a machine that
	* requires it in order to write binary files.
	*/
	if ((outfile = fopen(filename, "wb")) == NULL)
	{
    	fprintf(stderr, "Library error! Can't open %s\n", filename);
    	exit(1);
  	}
  
  	jpeg_stdio_dest(&cinfo, outfile);

	/* Step 3: set parameters for compression */

	/* First we supply a description of the input image.
	* Four fields of the cinfo struct must be filled in:
	*/
	cinfo.image_width = image_width; 	/* image width and height, in pixels */
	cinfo.image_height = image_height;
	cinfo.input_components = numberOfComponents;		/* # of color components per pixel */
	//cinfo.in_color_space = JCS_RGB; 	/* colorspace of input image */
	cinfo.in_color_space = colorSpace; 	/* colorspace of input image */
	//cinfo.in_color_space = JCS_GRAYSCALE; 	/* colorspace of input image */
	/* Now use the library's routine to set default compression parameters.
	* (You must set at least cinfo.in_color_space before calling this,
	* since the defaults depend on the source color space.)
	*/
	jpeg_set_defaults(&cinfo);
	/* Now you can set any non-default parameters you wish to.
	* Here we just illustrate the use of quality (quantization table) scaling:
	*/
	jpeg_set_quality(&cinfo, quality, TRUE /* limit to baseline-JPEG values */);

	/* Step 4: Start compressor */

	/* TRUE ensures that we will write a complete interchange-JPEG file.
	* Pass TRUE unless you are very sure of what you're doing.
	*/
	jpeg_start_compress(&cinfo, TRUE);

	/* Step 5: while (scan lines remain to be written) */
	/*           jpeg_write_scanlines(...); */

	/* Here we use the library's state variable cinfo.next_scanline as the
	* loop counter, so that we don't have to keep track ourselves.
	* To keep things simple, we pass one scanline per call; you can pass
	* more if you wish, though.
	*/
	row_stride = image_width * numberOfComponents;	/* JSAMPLEs per row in image_buffer */

	while (cinfo.next_scanline < cinfo.image_height)
	{
    	/* jpeg_write_scanlines expects an array of pointers to scanlines.
		* Here the array is only one element long, but you could pass
		* more than one scanline at a time if that's more convenient.
		*/
		row_pointer[0] = & image_buffer[cinfo.next_scanline * row_stride];
		(void) jpeg_write_scanlines(&cinfo, row_pointer, 1);
	}

	/* Step 6: Finish compression */

	jpeg_finish_compress(&cinfo);
	/* After finish_compress, we can close the output file. */
	fclose(outfile);

	/* Step 7: release JPEG compression object */

	/* This is an important step since it will release a good deal of memory. */
	jpeg_destroy_compress(&cinfo);

	/* And we're done! */
	return 2;
}


long int findFILEsize(char *fileName)
{
		FILE *file = fopen(fileName, "rb");
		if ( !(file) )
		{
			printf("\n	Cannot open file!!!\n");
			exit(1);
		}
		fseek(file, 0, SEEK_END);
		long int file_len = ftell(file);
		//printf("\nThe size of the file is: %ld bytes\n", file_len);
		rewind(file);
		fclose(file);
		return file_len;
}


void analyseNewJPEG (char *inputJPEG, char *outputJPEG, char *inputRAW, char *outputRAW, int xImageSize, int yImageSize, int numberOfComponents)
{

	//Setting up FILE IO
	FILE *tempFileRead1 = fopen(outputRAW, "rb");
	FILE *tempFileRead2 = fopen(inputRAW, "rb");
	unsigned char rawOriginal[yImageSize][xImageSize][numberOfComponents];
	unsigned char  rawCreated[yImageSize][xImageSize][numberOfComponents];

	//Open file and stop if it does not open
	if ( !(tempFileRead1) && !(tempFileRead2) )
	{
		printf("\n	Cannot open files!\n	PSNR Calculation failed!\n");
		exit(1);
	}

	//Read the files into 'temporary' image buffers
	fread(rawOriginal, sizeof(unsigned char), yImageSize*xImageSize*numberOfComponents, tempFileRead1);
	fread(rawCreated, sizeof(unsigned char), yImageSize*xImageSize*numberOfComponents, tempFileRead2);
	fclose(tempFileRead1);
	fclose(tempFileRead2);
	
	//PSNR Calculation
	//The MAX value a pixel can take is 255 or 2^b-1
	//Where b is the number of bits for 1 pixel
	//Which is 8 in case of grayscale images
	printf("\nJPEG Analysis info:");
	
	//Setting up parameters	
	long int sizeRAWinput   = findFILEsize(inputRAW);
	long int sizeJPEGinput  = findFILEsize(inputJPEG);
	long int sizeRAWoutput  = findFILEsize(outputRAW);
	long int sizeJPEGoutput = findFILEsize(outputJPEG);
	
	double compressionRatioInput  = ((double)sizeRAWinput)/((double)sizeJPEGinput);
	double compressionRatioOutput = ((double)sizeRAWoutput)/((double)sizeJPEGoutput);
	double savingsRatioInput      = 100 - (((double)sizeJPEGinput*100)/((double)sizeRAWinput));
	double savingsRatioOutput     = 100 - (((double)sizeJPEGoutput*100)/((double)sizeRAWoutput));

	double sumSqDiff = 0;
	double meanSqError = 0;
	double psnr = 0;
	double  MAX = 255;
	int xSizeOfPSNRblock = xImageSize;
	int ySizeOfPSNRblock = yImageSize;
	long numberOfPixels = xImageSize*yImageSize;
	int psnrCalcBlock[ySizeOfPSNRblock][xSizeOfPSNRblock][numberOfComponents];

	//Calculating the PSNR for the supplied pair of images
	for(int y=0; y<ySizeOfPSNRblock; y++){
		for(int x=0; x<xSizeOfPSNRblock; x++){
			psnrCalcBlock[y][x][0] = rawCreated[y][x][0] - rawOriginal[y][x][0];
			//psnrCalcBlock[y][x][0] = (int)rawCreated[y][x][0] - (int)rawOriginal[y][x][0];
			sumSqDiff += pow(psnrCalcBlock[y][x][0], 2);
		}
	}
	
	meanSqError = sumSqDiff/numberOfPixels;
	psnr = 10*log10( pow(MAX, 2) / meanSqError );
	
	printf("\n	Size input JPEG image : %ld bytes", sizeJPEGinput);
	printf("\n	Size input RAW image  : %ld bytes", sizeRAWinput);
	printf("\n	Size output JPEG image: %ld bytes", sizeJPEGoutput);
	printf("\n	Size output RAW image : %ld bytes", sizeRAWoutput);
	printf("\n	Compression Ratio: %.02f", compressionRatioInput);
	printf("\n	Savings before application          : %.02f(%%)", savingsRatioInput);
	printf("\n	Compression Ratio before application: %.02f", compressionRatioInput);
	printf("\n	Savings after application           : %.02f(%%)", savingsRatioOutput);
	printf("\n	Compression Ratio after application : %.02f", compressionRatioOutput);
	printf("\n	MSE after application : %.02f", meanSqError);
	printf("\n	PSNR after application: %.02f\n", psnr);

}

void createGaussianFilter(int kernelSize, double sigma, double gaussKernel[kernelSize][kernelSize])
{
    // Standard Deviation (sigma) is set to 1.0
    double numeratorForExp;
    double denominatorForExp = 2.0 * sigma * sigma;
 
    // Sum is for normalization
    double sum = 0.0;
 
    // Generating 3x3 kernel
    for (int y = -(kernelSize/2); y < 1+(kernelSize/2); y++)
    {
    	//printf("y = %d 	", y);
        for(int x = -(kernelSize/2); x < 1+(kernelSize/2); x++)
        {
        	//printf("x = %d 	", x);
            numeratorForExp = x*x + y*y;
            gaussKernel[y + (kernelSize/2)][x + (kernelSize/2)] = (exp(-(numeratorForExp)/denominatorForExp) )/(M_PI * denominatorForExp);
            sum += gaussKernel[y + (kernelSize/2)][x + (kernelSize/2)];
        }
    }
 
    // normalize the Kernel
    for(int y = 0; y < kernelSize; y++)
    {
        for(int x = 0; x < kernelSize; x++)
            gaussKernel[y][x] /= sum;
    }
 
}

void ApplyingGaussianFilter(int kernelSize, double gaussKernel[kernelSize][kernelSize], int outputImageHeight, int outputImageWidth, int numberOfComponents, char *inputRAWfile, char *outputGaussRAWfile)
{
    //Creating a NULL-initialised RAW image buffer with increased dimensions
    //Edges of the original image are replicated to fill up the blank space
    //This is done so that the edges and corners can be smoothed
    unsigned char filterBuffer[outputImageHeight + kernelSize - 1][outputImageWidth + kernelSize - 1][numberOfComponents];
    for(int j=0; j<outputImageHeight + kernelSize - 1; j++)
    	for(int i=0; i<outputImageWidth + kernelSize - 1; i++)
    		for(int k=0; k<numberOfComponents; k++)
    			filterBuffer[j][i][k] = 0;
    
	unsigned char tempRAWimage[outputImageHeight][outputImageWidth][numberOfComponents];
    FILE *file = fopen(inputRAWfile, "rb");  
	if (!(file))
	{
		printf("Cannot open file!!");
		exit(1);
	}
	
	fread(tempRAWimage, sizeof(unsigned char), outputImageHeight*outputImageWidth*numberOfComponents, file);
	fclose(file);
	
	printf("\n");
	//Copying the raw image in to middle of the block
	for(int j=0; j<outputImageHeight; j++)
    	for(int i=0; i<outputImageWidth; i++)
    		for(int k=0; k<numberOfComponents; k++)
    			filterBuffer[ j+(kernelSize/2) ][ i+(kernelSize/2) ][k] = tempRAWimage[j][i][k];
    //Copying the top edge to the upper blank space
	for(int j=0; j<(kernelSize/2)+1; j++)
    	for(int i=0; i<outputImageWidth; i++)
    		for(int k=0; k<numberOfComponents; k++)
    			filterBuffer[j][ i+(kernelSize/2) ][k] = tempRAWimage[0][i][k];
    //Copying the bottom edge to the lower blank space
    for(int j=outputImageHeight; j < outputImageHeight + kernelSize - 1; j++)
    	for(int i=0; i<outputImageWidth; i++)
    		for(int k=0; k<numberOfComponents; k++)
    			filterBuffer[j][ i+(kernelSize/2) ][k] = tempRAWimage[outputImageHeight-1][i][k];
    //Copying the left edge to blank space on eft
    for(int j=0; j<outputImageHeight; j++)
    	for(int i=0; i < (kernelSize/2)+1; i++)
    		for(int k=0; k<numberOfComponents; k++)
    			filterBuffer[ j+(kernelSize/2) ][i][k] = tempRAWimage[j][0][k];
    //Copying the right edge to blank space on right
    for(int j=0; j<outputImageHeight; j++)
    	for(int i=outputImageWidth; i < outputImageWidth + kernelSize - 1; i++)
    		for(int k=0; k<numberOfComponents; k++)
    			filterBuffer[ j+(kernelSize/2) ][i][k] = tempRAWimage[j][outputImageHeight-1][k];


 	//FILE *tempoutputRAWfile = fopen("../src/TEMPclock1.raw", "w");
 	//if (!(tempoutputRAWfile))
	//{
	//	printf("Cannot open file!!");
	// 	exit(1);
	//}
 	//fwrite(filterBuffer, sizeof(char), (outputImageHeight + kernelSize - 1)*(outputImageWidth + kernelSize - 1)*numberOfComponents, tempoutputRAWfile);
 	//fclose(tempoutputRAWfile);
	
    double tempKernelbuffer[kernelSize][kernelSize];
    unsigned char tempRAWimage2[outputImageHeight][outputImageWidth][numberOfComponents];

    for(int q=0; q<outputImageHeight; q++)
    {
    	for(int p=0; p<outputImageWidth; p++)
    	{
    		for(int r=0; r<numberOfComponents; r++)
    		{
    			double runningSum = 0;
    			for(int j=0; j<kernelSize; j++)
			    {
			    	for(int i=0; i<kernelSize; i++)
			    	{
			    		tempKernelbuffer[j][i] = (double)filterBuffer[ j+q ][ i+p ][r] * gaussKernel[j][i];
			    		runningSum += tempKernelbuffer[j][i];
			    	}
			    }
			    tempRAWimage[q][p][r] = (unsigned char)runningSum;
    		}
	    		
    	}
    	
    }

		    
    FILE *outputfile = fopen(outputGaussRAWfile, "w");
    if (!(outputfile))
	{
		printf("Cannot open file!!");
		exit(1);
	}
    fwrite(tempRAWimage, sizeof(char), (outputImageHeight)*(outputImageWidth)*numberOfComponents, outputfile);
    fclose(outputfile);
}


int main ()
{

	printf("\nPlease make sure that there is a results folder in the directory to avoid errors!!\n\n");
	
	//Setting up INPUT Block
	int jpegQualityIndex[10] = {50, 50, 50, 50, 50, 50, 50, 50, 50, 50};
	char inputJPEGfileIndex[50];
	char outputRAWfileIndex[50];
	char outputJPEGfileIndex[50];
	char outputJPEGfileIndex2[50];
	char outputRAWfileIndex_processed [50];
	char outputRAWfileIndex_processed2 [50];


	//Setting up Parameters
	int outputImageHeight  = 256;	
	int outputImageWidth   = 256;
	int numberOfComponents;
	J_COLOR_SPACE colorSpace;

	int kernelSize = 9;
	double sigma = 1;
	double gaussKernel[kernelSize][kernelSize];
    createGaussianFilter( kernelSize, sigma, gaussKernel);
    printf("\nA %dx%d Gaussian kernel with sigma = %0.1f:\n", kernelSize, kernelSize, sigma);
    for(int y = 0; y < kernelSize; y++)
    {
        for (int x = 0; x < kernelSize; x++)
        {
            printf("%0.003f	", gaussKernel[y][x]);
        }
        printf("\n");
    }


	for(int i = 0; i < 10; i++)
	{
		char indexString[5];
		char inputFILEname [50];
		char processedFILEname [50];
		char processedFILEname2 [50];

		if(i<5)
		{
			strcpy(inputFILEname, "../src/clock");
			strcpy(processedFILEname, "../results/gauss_clock");
			strcpy(processedFILEname2, "../results/final_clock");
			sprintf(indexString, "%d", i+1);
		} else {
			strcpy(inputFILEname, "../src/pepper");
			strcpy(processedFILEname, "../results/gauss_pepper");
			strcpy(processedFILEname2, "../results/final_pepper");
			sprintf(indexString, "%d", i-4);
		}


		strcpy(inputJPEGfileIndex, inputFILEname);
		strcat(inputJPEGfileIndex, indexString);
		strcat(inputJPEGfileIndex, ".jpg");
		//printf("\n%s\n", inputJPEGfileIndex);

		strcpy(outputRAWfileIndex, inputFILEname);
		strcat(outputRAWfileIndex, indexString);
		strcat(outputRAWfileIndex, ".raw");
		//printf("\n%s\n", outputRAWfileIndex);
		
		strcpy(outputJPEGfileIndex, processedFILEname);
		strcat(outputJPEGfileIndex, indexString);
		strcat(outputJPEGfileIndex, ".jpg");
		//printf("\n%s\n", outputJPEGfileIndex);

		strcpy(outputRAWfileIndex_processed, processedFILEname);
		strcat(outputRAWfileIndex_processed, indexString);
		strcat(outputRAWfileIndex_processed, ".raw");
		//printf("\n%s\n", outputRAWfileIndex_processed);

		strcpy(outputJPEGfileIndex2, processedFILEname2);
		strcat(outputJPEGfileIndex2, indexString);
		strcat(outputJPEGfileIndex2, ".jpg");
		//printf("\n%s\n", outputJPEGfileIndex);

		strcpy(outputRAWfileIndex_processed2, processedFILEname2);
		strcat(outputRAWfileIndex_processed2, indexString);
		strcat(outputRAWfileIndex_processed2, ".raw");
		//printf("\n%s\n", outputRAWfileIndex_processed);


		printf("\n\nProcessing input JPEG file: %s", inputJPEGfileIndex);	
		
		//JPEG Reading Block - Read input JPEG image
		//Setting up Parameters
		char *inputJPEGfile = inputJPEGfileIndex;
		char *outputRAWfile = outputRAWfileIndex;
		bool createRawfile = TRUE;
		
		//Generating RAW Files for input JPEG images
		if(read_JPEG_file(inputJPEGfile, createRawfile, outputRAWfile))
		{
			//printf("\n	JPEG file was read: %s\n", inputJPEGfile);
			if (createRawfile)
			{
				printf("\nRAW file was written: %s", outputRAWfile);
			}
		}


		//JPEG Writing Block
		//Setting up Parameters
		outputImageHeight  = 256;	
		outputImageWidth   = 256;
		if (i<5)
		{
			numberOfComponents = 1;
			colorSpace = JCS_GRAYSCALE;
		} else {
			numberOfComponents = 3;
			colorSpace = JCS_RGB;
		}


		
		//Setting up FILE IO
		char *inputRAWfile = outputRAWfile; 
		char *outputJPEGfile = outputJPEGfileIndex;
		char *outputGaussRAWfile = outputRAWfileIndex_processed;
		//Applying Gaussian Smoothing Filter
		ApplyingGaussianFilter(kernelSize, gaussKernel, outputImageHeight, outputImageWidth, numberOfComponents, inputRAWfile, outputGaussRAWfile);
		

		//Generating JPEG Files of desired quality
		int jpegQuality = jpegQualityIndex[i];
		inputRAWfile = outputRAWfileIndex_processed;
		if(write_JPEG_file(outputJPEGfile, jpegQuality, outputImageHeight, outputImageWidth, numberOfComponents, colorSpace, inputRAWfile))
		{
			printf("\nOutput JPEG file,  %s, was written with quality: %d%%", outputJPEGfileIndex, jpegQualityIndex[i]);
		}


		//JPEG Reading Block - Read Gaussian Filtered JPEG Images
		//Setting up Parameters
		inputJPEGfile = outputJPEGfileIndex;
		outputRAWfile = outputRAWfileIndex_processed2;
		createRawfile = TRUE;
		
		//Generating RAW Files for input JPEG images
		if(read_JPEG_file(inputJPEGfile, createRawfile, outputRAWfile))
		{
			//printf("\n	JPEG file was read: %s\n", inputJPEGfile);
			if (createRawfile)
			{
				printf("\nRAW file was written: %s", outputRAWfile);
			}
		}		

		//JPEG Analysis block - Compare the original and Gaussian filtered images
		inputJPEGfile  = inputJPEGfileIndex;
		outputJPEGfile = outputJPEGfileIndex;
		inputRAWfile   = outputRAWfileIndex;
		outputRAWfile  = outputRAWfileIndex_processed2;
		analyseNewJPEG (inputJPEGfile, outputJPEGfile, inputRAWfile, outputRAWfile, outputImageWidth, outputImageHeight, numberOfComponents);

		inputJPEGfileIndex[0]  = '\0';
		outputRAWfileIndex[0]  = '\0';
		outputJPEGfileIndex[0] = '\0';
		outputRAWfileIndex_processed[0]  = '\0';
		outputRAWfileIndex_processed2[0] = '\0';

	}

}